#!/usr/bin/env python
import rospy
import numpy as np
import cv2
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
from lane_test.msg import msg


class Image:
    def __init__(self):
	self.bridge = CvBridge()
	self.angle = msg()
        self.img_sub = None
        self.img_pub = None
        self.img = None
        self.ori_img = None
        self.img_rst = None
        self.img_canny = None
        self.edge = None
        self.line = None
        self.value_ye = None
        self.value_wh = None
        self.line_md = []
        self.line_wh = []
        self.line_ye = []

    def sub_img(self, image):
        self.img_sub = self.bridge.imgmsg_to_cv2(image)
   
    def pub_img(self, image):
        self.img_pub = self.bridge.cv2_to_imgmsg(image)

     def frame_img(self, image):
        self.ori_img = image
        self.img_rst = self.ori_img[120:310, 0:320]
        self.img_ye = self.ori_img[100:310, 0:160]
        self.img_wh = self.ori_img[100:310, 160:320]
        self.img_copy = self.img_rst.copy()

    def bgr_to_gray(self, image):
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    def img_hstack(self, img1, img2, img3):
        img1 = np.hstack([img2, img3])

    def edge(self, img):
        self.bgr_to_gray(self, img)
        blur = cv2.GaussianBlur(img, (7, 7), 0)
        self.img_canny = cv2.Canny(blur, 150, 200)

    def filter_region(self, img, vertices):
        mask = np.zeros_like(img)
        if len(mask.shape) == 2:
            cv2.fillPoly(mask, vertices, 255)
        else:
            cv2.fillPoly(mask, vertices, (255,) * mask.shape[2])
        return cv2.bitwise_and(img, mask)

    def select_region(self, img):
        rows, cols = img.shape[:2]
        bottom_left = [cols * 0.0, rows * 0.6]
        top_left = [cols * 0.0, rows * 0.4]
        bottom_right = [cols * 1, rows * 0.6]
        top_right = [cols * 0.85, rows * 0.4]
        vertices = np.array([[bottom_left, top_left, top_right, bottom_right]], dtype=np.int32)
        self.img_canny = self.filter_region(self, img, vertices)

    def get_line(self):
        self.line = cv2.HoughLinesP(self.img_canny, rho=1, theta=np.pi/180, threshold=50, minLineLength=1, maxLineGap=30)
        for line in self.line:
            x1, y1, x2, y2 = line[0]
            cv2.line(self.img_copy, (x1, y1), (x2, y2), [255, 0, 0], 2)

    def average_slope_intercept(self):
        left_lines = []
        left_weights = []
        right_lines = []
        right_weights = []

        for line in self.line:
            for x1, y1, x2, y2 in line:
                if x2 == x1:
                    continue

                slope = (y2 - y1) / (x2 - x1)
                intercept = y1 - slope * x1
                length = np.sqrt((y2 - y1) ** 2 + (x2 - x1) ** 2)
                if slope < 0:  # y is reversed in image
                    left_lines.append((slope, intercept))
                    left_weights.append((length))
                else:
                    right_lines.append((slope, intercept))
                    right_weights.append((length))

        self.line_ye = np.dot(left_weights, left_lines) / np.sum(left_weights) if len(left_weights) > 0 else None
        self.line_wh = np.dot(right_weights, right_lines) / np.sum(right_weights) if len(
            right_weights) > 0 else None

    def make_line_points_ye(self, y1, y2):
        if self.line_ye is None:
            return None

        slope, intercept = self.line_ye

        self.x1_ye = int((y1 - intercept) / slope)
        self.x2_ye = int((y2 - intercept) / slope)
        self.y1_ye = int(y1)
        self.y2_ye = int(y2)

    def make_line_points_wh(self, y1, y2):
        if self.line_wh is None:
            return None

        slope, intercept = self.line_wh

        self.x1_wh = int((y1 - intercept) / slope)
        self.x2_wh = int((y2 - intercept) / slope)
        self.y1_wh = int(y1)
        self.y2_wh = int(y2)

    def draw_lines(self):
        y1 = self.img_canny.shape[0]  # bottom of the image
        y2 = y1 * 0.6  # slightly lower than the middle

        self.make_line_points_ye(self, y1, y2)
        self.make_line_points_wh(self, y1, y2)

        x1 = (self.x1_wh + self.x1_ye) // 2
        x2 = (self.x2_wh + self.x2_ye) // 2
        y1 = (self.y1_wh + self.y1_ye) // 2 -50
        y2 = (self.y2_wh + self.y2_ye) // 2 -50
	
	msg.angle = np.pi - (np.arctan((y1-y2)/(x1-x2)) * (180.0/np.pi))
	rospy.loginfo("%s" % (msg.angle))

        #self.line_md.append((x1, y1, x2, y2))

        cv2.line(self.img_copy, (x1, y1), (x2, y2), [255, 0, 0], 2)


def main():
    pub = rospy.Publisher('/image_raw', Image, queue_size = 1)
    rospy.init_node("webcam")
    rate = rospy.Rate(10)
    img_now = Image
    cap = cv2.VideoCapture(1)
    cap.set(3, 320)
    cap.set(4, 240)
    if not cap.isOpened():
        print("open fail video")
    while not rospy.is_shutdown():
        ret, frame = cap.read()
        if ret:
            img_now.frame_img(img_now, frame)
            img_now.edge(img_now, img_now.img_rst)
            img_now.select_region(img_now, img_now.img_canny)
            img_now.get_line(img_now)
            img_now.average_slope_intercept(img_now)
            img_now.draw_lines(img_now)
            frame_ = bridge.cv2_to_imgmsg(img_now.img_copy, "bgr8")
	    pub.publish(frame_)

            k = cv2.waitKey(10)
            if k == 27:
                cap.release()
                cv2.destroyAllWindows()
                break
    rate.sleep()


if __name__ == '__main__':
	try :
		main()
	except rospy.ROSInterruptException:
		pass

